0.6.0 (2016-03-21)
------------------
* Better instruction formatting
* support holonomic base, send commmand with keyboard down
* Fixing queue_size warning
* Create README.md
* Update the description string in package.xml
* Contributors: Austin, Kei Okada, LiohAu, Mike Purvis, kk6axq, trainman419

0.5.0 (2014-02-11)
------------------
* Initial import from brown_remotelab
* Convert to catkin
